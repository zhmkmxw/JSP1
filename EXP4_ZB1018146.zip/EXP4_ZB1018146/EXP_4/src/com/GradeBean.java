package com;

public class GradeBean {
		
	private double history;
	private double chinese;
	private double math;
	private double science;
	private double english;
	
	public GradeBean() {
		super();
	}
	public GradeBean(double math, double history, double chinese, double science, double english) {
		super();
		this.math = math;
		this.history = history;
		this.chinese = chinese;
		this.science = science;
		this.english = english;
	}
	public double getMath() {
		return math;
	}
	public void setMath(double math) {
		this.math = math;
	}
	public double getHistory() {
		return history;
	}
	public void setHistory(double history) {
		this.history = history;
	}
	public double getChinese() {
		return chinese;
	}
	public void setChinese(double chinese) {
		this.chinese = chinese;
	}
	public double getScience() {
		return science;
	}
	public void setScience(double science) {
		this.science = science;
	}
	public double getEnglish() {
		return english;
	}
	public void setEnglish(double english) {
		this.english = english;
	}
	
	
}

