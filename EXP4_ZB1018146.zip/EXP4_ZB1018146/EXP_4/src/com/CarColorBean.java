package com;


public class CarColorBean {
	private String color;
	private boolean flag;
	
	public CarColorBean() {
		super();
	}
	public CarColorBean(String color, boolean flag) {
		super();
		this.color = color;
		this.flag = flag;
	}
	public String getColor() {
		return color;
	}
	public void setColor(String color) {
		this.color = color;
	}
	public boolean isFlag() {
		return flag;
	}
	public void setFlag(boolean flag) {
		this.flag = flag;
	}
}

